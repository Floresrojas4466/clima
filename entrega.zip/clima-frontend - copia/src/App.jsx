import {BrowserRouter,Routes,Route} from "react-router-dom"

import Login from "./pages/Login"
import Clima from "./pages/Clima"
import Historial from "./pages/Historial"

function App(){

return(

<BrowserRouter>

<Routes>

<Route path="/" element={<Login/>}/>
<Route path="/clima" element={<Clima/>}/>
<Route path="/historial" element={<Historial/>}/>

</Routes>

</BrowserRouter>

)

}

export default App