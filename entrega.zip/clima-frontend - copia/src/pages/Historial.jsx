import {useNavigate} from "react-router-dom"

function Historial(){

const navigate = useNavigate()

const ciudad = localStorage.getItem("ciudad")
const temp = localStorage.getItem("temp")
const estado = localStorage.getItem("estado")

return(

<div className="clima-container">

<div className="clima-card">

<h1>📜 Historial</h1>

<p>Ciudad: {ciudad}</p>
<p>Temperatura: {temp} °C</p>
<p>Estado: {estado}</p>

<br/>

<button onClick={()=>navigate("/")}>
Volver al Login
</button>

</div>

</div>

)

}

export default Historial