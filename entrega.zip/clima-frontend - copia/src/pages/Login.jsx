import {useNavigate} from "react-router-dom"
import {useState} from "react"

function Login(){

const navigate = useNavigate()

const [usuario,setUsuario] = useState("")
const [pass,setPass] = useState("")

const entrar = ()=>{

if(usuario==="admin" && pass==="1234"){

navigate("/clima")

}else{

alert("Usuario incorrecto")

}

}

return(

<div className="login-container">

<div className="login-card">

<h1>🌦 Weather System</h1>

<input
placeholder="Usuario"
onChange={(e)=>setUsuario(e.target.value)}
/>

<input
type="password"
placeholder="Contraseña"
onChange={(e)=>setPass(e.target.value)}
/>

<button onClick={entrar}>
Ingresar
</button>

</div>

</div>

)

}

export default Login