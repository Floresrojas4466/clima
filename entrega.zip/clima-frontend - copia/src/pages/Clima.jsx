import {useState} from "react"
import {useNavigate} from "react-router-dom"

function Clima(){

const navigate = useNavigate()

const [ciudad,setCiudad] = useState("")
const [temp,setTemp] = useState(null)
const [estado,setEstado] = useState("")
const [humedad,setHumedad] = useState(null)

const buscar = async ()=>{

try{

const API="9a5b037621b1d723aa50abc30648ca3d"

const url=`https://api.openweathermap.org/data/2.5/weather?q=${ciudad}&units=metric&lang=es&appid=${API}`

const res = await fetch(url)

const data = await res.json()

if(data.cod !== 200){
alert("Ciudad no encontrada")
return
}

setTemp(data.main.temp)
setEstado(data.weather[0].description)
setHumedad(data.main.humidity)

localStorage.setItem("ciudad",ciudad)
localStorage.setItem("temp",data.main.temp)
localStorage.setItem("estado",data.weather[0].description)

}catch{

alert("Error consultando clima")

}

}

return(

<div className="clima-container">

<div className="clima-card">

<h1>🌦 Consulta del Clima</h1>

<input
placeholder="Ej: Bogota"
onChange={(e)=>setCiudad(e.target.value)}
/>

<button onClick={buscar}>
Consultar
</button>

{temp !== null && (

<div className="resultado">

<h2>{ciudad}</h2>

<p>🌡 Temperatura: {temp} °C</p>

<p>☁ Estado: {estado}</p>

<p>💧 Humedad: {humedad}%</p>

</div>

)}

<button onClick={()=>navigate("/historial")}>
Ver historial
</button>

</div>

</div>

)

}

export default Clima